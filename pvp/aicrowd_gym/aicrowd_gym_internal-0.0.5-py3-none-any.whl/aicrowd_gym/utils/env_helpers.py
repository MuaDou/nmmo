#  Copyright (c) 2022. AIcrowd. All rights reserved.

import os


def get_env(
    env_var: str, default_value: str = None, error_on_empty: bool = True
) -> str:
    value = os.getenv(env_var, default_value)
    if value is None and error_on_empty:
        raise ValueError(f"Environment variable `{env_var}` should be specified")
    return value
