#  Copyright (c) 2022. AIcrowd. All rights reserved.

import socket
import uuid
from typing import Any, Dict, List

from loguru import logger

from aicrowd_gym.constants import StatusOptions
from aicrowd_gym.serializers.base import BaseSerializer
from aicrowd_gym.servers.base_actions import AgentServiceActions


class BaseOracleClient:
    """Base client to communicate with oracle server during evaluations."""

    agent: object
    agent_server_host: str
    agent_server_port: int

    def __init__(self, serializer: BaseSerializer):
        """Initialize oracle client

        Args:
            serializer: Serializer to decode and encode data between client
                and server.
        """
        self.serializer = serializer
        self.id = str(uuid.uuid4())
        self._exit_server = False

    @staticmethod
    def get_host_ip() -> str:
        """Get the default network interface's IP address.

        Returns:
            The IP address of the default network interface.
        """
        _socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        _socket.connect(("8.8.8.8", 1))
        return _socket.getsockname()[0]

    def _send_oracle_server_data(self, data: Any):
        """Method to send data to the oracle server. This should be a blocking
        call.

        Args:
            data: Data that needs to be sent to oracle server.
        """
        raise NotImplementedError

    def _recv_oracle_server_data(self) -> Any:
        """Method to receive data from the oracle server. This should be a
        blocking call.

        Returns:
            Data received from the oracle server.
        """
        raise NotImplementedError

    def _send_server_request(self, data):
        """Send encoded request to oracle server.

        Args:
            data: Encoded request that needs to be sent to the server.
        """
        self._send_oracle_server_data(data)

    def _receive_server_response(self):
        """Receive encoded response from the oracle server and parse it.

        Returns:
            Decoded response from the oracle server
        """
        raw_response = self._recv_oracle_server_data()
        response, status, message = self.serializer.decode_response(raw_response)
        if status != StatusOptions.SUCCESS:
            raise ValueError(message)
        return response

    def process_request(
        self,
        action: str,
        target_attribute: str,
        instance_id: str,
        args: List[Any],
        kwargs: Dict[str, Any],
    ):
        """Process the incoming requests to the agent server.

        Args:
            action: Action to execute on the agent server. This should be one
                of `aicrowd_gym.servers.base_actions.AgentServiceActions`.
            target_attribute: Method to execute on the agent.
            instance_id: Request ID or server ID.
            args: Positional arguments passed to the `target_attribute`.
            kwargs: Additional named arguments passed to the `target_attribute`.
        """
        try:
            response = {
                "data": self.route_agent_request(
                    action, target_attribute, instance_id, args, kwargs
                ),
                "id": instance_id,
            }
            return response, StatusOptions.SUCCESS, ""
        except Exception:
            raise

    def route_agent_request(
        self,
        action: str,
        target_attribute: str,
        instance_id: str,
        args: List[Any],
        kwargs: Dict[str, Any],
    ):
        """Routes the incoming requests to the agent server.

        Args:
            action: Action to execute on the agent server. This should be one
                of `aicrowd_gym.servers.base_actions.AgentServiceActions`.
            target_attribute: Method to execute on the agent.
            instance_id: Request ID or server ID.
            args: Positional arguments passed to the `target_attribute`.
            kwargs: Additional named arguments passed to the `target_attribute`.
        """
        if action == AgentServiceActions.PING:
            return self.health_check()
        if action == AgentServiceActions.EXECUTE_CLIENT_METHOD:
            return self.execute(target_attribute, *args, **kwargs)
        if action == AgentServiceActions.STOP_CLIENT:
            return self.stop_server()

    def execute(self, target_method: str, *args, **kwargs):
        """Execute a method on the agent.

        Args:
            target_method: Method that needs to be executed on the agent.
            args: Positional arguments passed to the `target_method`.
            kwargs: Additional named arguments passed to the `target_method`.
        """
        method = getattr(self.agent, target_method)
        return method(*args, **kwargs)

    def health_check(self) -> str:
        return self.id

    def stop_server(self):
        """Stop the running server.

        The server runs in a while loop conditioned on `self._exit_server`.
        This method sets `self._exit_server` to `True` and expects the while
        loop to stop on the next request. This method is expected to be invoked
        from oracle server which will make sure that the loop is not blocked on
        receiving server data.
        """
        self._exit_server = True

    def _send_agent_server_data(self, data: Any):
        """Send data from the agent server to oracle server. This should be a
        blocking call.

        Args:
            data: Data to be sent from agent server.
        """
        raise NotImplementedError

    def _recv_agent_server_data(self) -> Any:
        """Receive data from oracle server on agent server. This should be a
        blocking call.

        Returns:
            Data sent from oracle server to the agent.
        """
        raise NotImplementedError

    def run_agent(self):
        """Server loop."""
        if self.agent is None:
            raise ValueError(
                "You need to register the agent before running the agent loop."
            )

        while not self._exit_server:
            message = self._recv_agent_server_data()
            (
                instance_id,
                action,
                target,
                args,
                kwargs,
                client_delays,
            ) = self.serializer.decode_request(message)
            raw_response, status, message = self.process_request(
                instance_id=instance_id,
                action=action,
                target_attribute=target,
                args=args,
                kwargs=kwargs,
            )
            response = self.serializer.encode_response(raw_response, status, message)
            self._send_agent_server_data(response)

    def register_agent(self, agent: object, metadata: Dict = None):
        """Register the agent on oracle server.

        Args:
            agent: The agent class that oracle takes control over.
            metadata: Additional metadata passed to oracle server.
        """
        logger.info("Registering agent with oracle...")
        if metadata is None:
            metadata = {}
        self.agent = agent
        payload = self.serializer.encode_request(
            instance_id=self.id,
            service_action=AgentServiceActions.REGISTER_CLIENT,
            kwargs={
                "host": self.agent_server_host,
                "port": self.agent_server_port,
                "id": self.id,
                "metadata": metadata,
            },
        )
        self._send_server_request(payload)
        self._receive_server_response()
        logger.success("Registered agent with oracle")
