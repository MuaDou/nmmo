#  Copyright (c) 2022. AIcrowd. All rights reserved.

from typing import Any

import numpy as np
import zmq

from aicrowd_gym.clients.base_oracle_client import BaseOracleClient
from aicrowd_gym.serializers.base import BaseSerializer


class ZmqOracleClient(BaseOracleClient):
    """ZeroMQ client to communicate with the oracle server during evaluations.

    Examples:
        >>> from aicrowd_gym.serializers import MessagePackSerializer
        >>> class AIcrowdAgent:
        ...     def __init__(self): pass
        ...     def register_reset(self, obs): return 1
        ...     def compute_action(self, obs, info=None): return 1
        >>> client = ZmqOracleClient(
        ...     host="127.0.0.1",
        ...     port=5000,
        ...     serializer=MessagePackSerializer(),
        ... )
        >>> agent = AIcrowdAgent()
        >>> client.register_agent(agent)
        >>> client.run_agent()
    """

    context: zmq.Context
    oracle_socket: zmq.Socket
    agent_server_socket: zmq.Socket

    def __init__(self, host: str, port: int, serializer: BaseSerializer):
        """Initialize ZeroMQ oracle client

        Args:
            host: Hostname or IP of the ZeroMQ oracle server
            port: Port on which ZeroMQ server is running
            serializer: Serializer to decode and encode data between client and server
        """
        super(ZmqOracleClient, self).__init__(serializer=serializer)

        self.init_zmq_socket(host, port)

    def init_zmq_socket(self, host: str, port: int):
        """Initialize the sockets for ZMQ"""
        self.context = zmq.Context.instance()

        self.oracle_socket = self.context.socket(zmq.REQ)
        self.oracle_socket.connect("tcp://{}:{}".format(host, port))

        self.agent_server_host = self.get_host_ip()
        self.agent_server_port = np.random.randint(10000, 50000)

        self.agent_server_socket = self.context.socket(zmq.REP)
        self.agent_server_socket.bind("tcp://0.0.0.0:{}".format(self.agent_server_port))

    def _send_oracle_server_data(self, data: Any):
        """Sends the encoded data to the oracle server.

        This is a blocking call.

        Args:
            data: Encoded data to send to oracle server.
        """
        self.oracle_socket.send(data)

    def _recv_oracle_server_data(self) -> Any:
        """Receives response from oracle server.

        This is a blocking call.

        Returns:
            Data encoded received from oracle server.
        """
        return self.oracle_socket.recv()

    def _send_agent_server_data(self, data: Any):
        """Sends encoded data from agent server (client) to oracle server.

        This is typically a response for a previous request from oracle
        server. This is a blocking call.

        Args:
            data: Encoded data to send to oracle server
        """
        self.agent_server_socket.send(data)

    def _recv_agent_server_data(self) -> Any:
        """Receives encoded data from oracle server for agent server.

        This typically has the information on which method to execute on the
        agent class. This is a blocking call.

        Returns:
            Encoded data sent from oracle server to the agent.
        """
        return self.agent_server_socket.recv()
