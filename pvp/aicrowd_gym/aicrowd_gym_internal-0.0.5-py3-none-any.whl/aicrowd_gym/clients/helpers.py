#  Copyright (c) 2022. AIcrowd. All rights reserved.

import importlib

from aicrowd_gym.clients.base import BaseGymClient
from aicrowd_gym.constants import EnvConstants
from aicrowd_gym.exceptions import ClientNotFoundError
from aicrowd_gym.utils.env_helpers import get_env


def import_client(client_name: str) -> BaseGymClient:
    """Imports the appropriate gym client based on the client name

    Args:
        client_name: Name of the gym client to load

    Returns:
        Python class of the gym client specified by `client_name`
    """
    clients = importlib.import_module("aicrowd_gym.clients")
    try:
        return getattr(clients, client_name)
    except AttributeError:
        raise ClientNotFoundError(
            "Failed to load the client `{}`. Available clients are {}".format(
                client_name, ",".join(clients.__all__)
            )
        )


def make(id: str, **kwargs):
    client_name = get_env(EnvConstants.CLIENT_NAME)
    client: BaseGymClient = import_client(client_name)
    return client.builder(env_name=id, **kwargs)
