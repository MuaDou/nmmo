#  Copyright (c) 2022. AIcrowd. All rights reserved.

from __future__ import annotations

import sys
from typing import Any, Callable, Dict, Union

import gym

from aicrowd_gym.constants import StatusOptions
from aicrowd_gym.core.wrapper import (
    DelayAttributes,
    set_delay_attributes,
    summarize_delays,
    time_call,
)
from aicrowd_gym.serializers.base import BaseSerializer
from aicrowd_gym.servers.base import EnvServiceActions


class BaseSpaceClient:
    """Base client to access remote gym environment's action and observation
    spaces.
    """

    def __init__(
        self,
        instance_id: str,
        space: str,
        serializer: BaseSerializer,
        request_processor: Callable,
    ):
        """Initialize action space client.

        Args:
            instance_id: ID of the environment on the server.
            space: Type of the space - can be one of action_space or
                observation_space.
            serializer: Serializer to decode and encode data between client
                and server.
            request_processor: Function that sends the receives the data
                between client and server.
        """
        self._instance_id = instance_id
        self._serializer = serializer
        self._process_request = request_processor
        if space not in [
            EnvServiceActions.ENV_ACTION_SPACE,
            EnvServiceActions.ENV_OBSERVATION_SPACE,
        ]:
            raise ValueError("space should be either action space or observation space")
        self._space = space

    def _build_request(self, service_action: str, *args, **kwargs) -> Any:
        """Build the request payload to send to the server.

        Args:
            service_action: Method or attribute to access in the action or
                observation space.
            *args: Positional arguments to pass to `service_action` in case
                it's a callable.
            **kwargs: Named arguments to pass to `service_action` in case it's
                a callable.

        Returns:
            Serialized request object.
        """
        return self._serializer.encode_request(
            instance_id=self._instance_id,
            service_action=self._space,
            target_attribute=service_action,
            args=args,
            kwargs=kwargs,
        )

    def contains(self, x: Union[int, float]) -> bool:
        """Proxy for `env.{action, observation}_space.contains`.

        Args:
            x: Value belonging to the space.

        Returns:
            True if x belongs to the space.
        """
        payload = self._build_request("contains", x)
        return self._process_request(data=payload)

    def sample(self) -> Union[int, float]:
        """Proxy for `env.{action, observation}_space.sample`

        Returns:
            A random value from the space
        """
        payload = self._build_request("sample")
        return self._process_request(data=payload)

    @property
    def shape(self):
        """Proxy for `env.{action, observation}_space.shape`

        Returns:
            Shape of the space
        """
        payload = self._build_request("shape")
        return self._process_request(data=payload)

    @property
    def bounded_above(self):
        """Proxy for `env.{action, observation}_space.bounded_above`"""
        payload = self._build_request("bounded_above")
        return self._process_request(data=payload)

    @property
    def bounded_below(self):
        """Proxy for `env.{action, observation}_space.bounded_below`"""
        payload = self._build_request("bounded_below")
        return self._process_request(data=payload)

    @property
    def high(self):
        """Proxy for `env.{action, observation}_space.high`"""
        payload = self._build_request("high")
        return self._process_request(data=payload)

    @property
    def low(self):
        """Proxy for `env.{action, observation}_space.low`"""
        payload = self._build_request("low")
        return self._process_request(data=payload)

    @property
    def n(self):
        payload = self._build_request("n")
        return self._process_request(data=payload)

    def is_bounded(self, manner):
        """Proxy for `env.{action, observation}_space.is_bounded`"""
        payload = self._build_request("is_bounded", manner)
        return self._process_request(data=payload)

    def __getitem__(self, key):
        payload = self._build_request("spaces")
        return self._process_request(data=payload)[key]

    def __iter__(self):
        payload = self._build_request("spaces")
        spaces = self._process_request(data=payload)
        for key in spaces:
            yield key

    def __len__(self):
        payload = self._build_request("spaces")
        spaces = self._process_request(data=payload)
        return len(spaces)

    def __contains__(self, item):
        return self.contains(item)

    def __getattr__(self, item):
        payload = self._build_request(item)
        return self._process_request(data=payload)


class BaseGymClient(gym.Env):
    """Base client to proxy requests to the remote gym environment"""

    def __init__(
        self,
        serializer: BaseSerializer,
        env_name: str = None,
        env_config: Dict[str, Any] = None,
        instance_id: str = None,
    ):
        """Initialize base gym client

        Args:
            serializer: Serializer to decode and encode data between client and server
            env_name: Name of the environment to create
            env_config: Config options to create environment
            instance_id: ID of the environment on the server
        """
        self._serializer = serializer
        set_delay_attributes(self)

        self._instance_id = None
        if instance_id is None:
            if env_name is None:
                raise ValueError(
                    "One of `instance_id` or `env_name` should be provided"
                )
            self._instance_id = self._create_env(env_name, env_config)
        else:
            self._instance_id = instance_id

        self.action_space = BaseSpaceClient(
            instance_id=self._instance_id,
            space=EnvServiceActions.ENV_ACTION_SPACE,
            serializer=serializer,
            request_processor=self._process_request,
        )
        self.observation_space = BaseSpaceClient(
            instance_id=self._instance_id,
            space=EnvServiceActions.ENV_OBSERVATION_SPACE,
            serializer=serializer,
            request_processor=self._process_request,
        )

    def _collect_client_delays(self):
        return summarize_delays(self)

    def _create_env(self, env_name: str, env_config: Dict[str, Any] = None) -> str:
        if env_config is None:
            env_config = {}
        payload = self._build_request(
            service_action=EnvServiceActions.ENV_CREATE,
            env_name=env_name,
            env_config=env_config,
        )
        return self._process_request(data=payload)

    def builder(self, env_name: str, **kwargs) -> BaseGymClient:
        """Method to fetch the needed parameters from the environment and
        return an initialized instance of the class
        """
        raise NotImplementedError

    def _build_request(self, service_action: str, *args, **kwargs):
        """Build the request payload to send to the server

        Args:
            service_action: Method to access on the gym environment
            *args: Positional arguments to pass to the `service_action` method
            **kwargs: Named arguments to pass to the `service_action` method

        Returns:
            Serialized request object
        """
        return self._serializer.encode_request(
            instance_id=self._instance_id,
            service_action=service_action,
            args=args,
            kwargs=kwargs,
            client_delay_stats=self._collect_client_delays(),
        )

    @time_call(
        total=DelayAttributes.TOTAL_PER_RESET_DELAY,
        previous=DelayAttributes.PREVIOUS_PER_RESET_DELAY,
        average=DelayAttributes.AVERAGE_PER_RESET_DELAY,
        counter=DelayAttributes.TOTAL_RESETS,
    )
    def reset(self) -> Any:
        """Proxy for `env.reset`"""
        payload = self._build_request(service_action=EnvServiceActions.ENV_RESET)
        return self._process_request(data=payload)

    @time_call(
        total=DelayAttributes.TOTAL_PER_STEP_DELAY,
        previous=DelayAttributes.PREVIOUS_PER_STEP_DELAY,
        average=DelayAttributes.AVERAGE_PER_STEP_DELAY,
        counter=DelayAttributes.TOTAL_STEPS,
    )
    def step(self, action) -> Any:
        """Proxy for `env.step`"""
        payload = self._build_request(
            service_action=EnvServiceActions.ENV_STEP, action=action
        )
        return self._process_request(data=payload)

    @property
    @time_call(total=DelayAttributes.TOTAL_MISC_CALLS_DELAY)
    def reward_range(self) -> Any:
        """Proxy for `env.reward_range`"""
        payload = self._build_request(
            service_action=EnvServiceActions.ENV_ATTRIBUTE,
            attribute_name="reward_range",
        )
        return self._process_request(data=payload)

    @property
    @time_call(total=DelayAttributes.TOTAL_MISC_CALLS_DELAY)
    def metadata(self) -> Any:
        """Proxy for `env.metadata`"""
        payload = self._build_request(
            service_action=EnvServiceActions.ENV_ATTRIBUTE, attribute_name="metadata"
        )
        return self._process_request(data=payload)

    @time_call(total=DelayAttributes.TOTAL_MISC_CALLS_DELAY)
    def close(self) -> Any:
        """Proxy for `env.close`"""
        payload = self._build_request(service_action=EnvServiceActions.ENV_CLOSE)
        return self._process_request(data=payload)

    @time_call(total=DelayAttributes.TOTAL_MISC_CALLS_DELAY)
    def __getattr__(self, attribute_name: str) -> Any:
        """Proxy for arbitrary attributes that are not part of `gym.Env`"""
        payload = self._build_request(
            service_action=EnvServiceActions.ENV_ATTRIBUTE,
            attribute_name=attribute_name,
        )
        return self._process_request(data=payload)

    def _send_request(self, data) -> Any:
        """Send the encoded request data to the server and return the server response

        Args:
            data: Encoded payload to send to the server

        Returns:
            Response from the server
        """
        raise NotImplementedError

    def _process_request(self, data: Any) -> Any:
        """Handle client-server request-response lifecycle.

        Send the encoded request to the server, receives the raw response from
        the server, decodes the raw response.

        Args:
            data: Encoded payload to send to the server.

        Returns:
            Decoded response from the server.

        Raises:
            Exception passed from the server on failure.
        """
        raw_response = self._send_request(data=data)
        response, status, message = self._serializer.decode_response(data=raw_response)
        if status == StatusOptions.FAILED:
            raise ValueError(message)
        if status == StatusOptions.STOPPED:
            print(message)
            sys.exit(0)
        return response
