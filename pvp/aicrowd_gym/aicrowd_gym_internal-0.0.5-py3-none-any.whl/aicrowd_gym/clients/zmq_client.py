#  Copyright (c) 2022. AIcrowd. All rights reserved.

from __future__ import annotations

import os
import sys
from typing import Any, Dict

import timeout_decorator
import zmq
from loguru import logger

from aicrowd_gym.clients.base import BaseGymClient
from aicrowd_gym.constants import EnvConstants
from aicrowd_gym.serializers.base import BaseSerializer
from aicrowd_gym.utils import env_helpers


class ZmqClientConfig:
    CLIENT_TIMEOUT_SECONDS = 60 * 5
    SUPPRESS_ZMQ_ERRORS = os.getenv("AICROWD_SUPPRESS_ZMQ_ERRORS", None) is not None


class ZeroMqClient(BaseGymClient):
    """ZeroMQ client to access remote gym environments hosted via ZeroMQ server

    Examples:
        >>> from aicrowd_gym.serializers import MessagePackSerializer
        >>> env = ZeroMqClient(
        ...     serializer=MessagePackSerializer(),
        ...     host="127.0.0.1",
        ...     port=5000,
        ... )
        >>> obs = env.reset()
        >>> done = False
        >>> total_reward = 0
        >>> while not done:
        ...     obs, done, reward, info = env.step(env.action_space.sample())
        ...     total_reward += reward
        >>> print("Total reward earned:", total_reward)
    """

    def __init__(
        self,
        serializer: BaseSerializer,
        host: str,
        port: int,
        instance_id: str = None,
        env_name: str = None,
        env_config: Dict[str, Any] = None,
    ):
        """Initialize ZeroMQ remote gym client

        Args:
            serializer: Serializer to decode and encode data between client and server
            host: Hostname or IP of the ZeroMQ server
            port: Port on which ZeroMQ server is running
            instance_id: ID of the environment on the server
            env_name: Name of the environment
            env_config: Config options to create environment
        """
        self._host = host
        self._port = port
        self._serializer = serializer
        self._init_socket()
        super().__init__(
            instance_id=instance_id,
            serializer=serializer,
            env_name=env_name,
            env_config=env_config,
        )

    def _init_socket(self):
        """Initialize the sockets for ZMQ"""
        self.context = zmq.Context.instance()
        self.socket = self.context.socket(zmq.REQ)
        self.socket.set(zmq.CONNECT_TIMEOUT, 20000)
        self.socket.set(zmq.RCVTIMEO, 20000)
        self.socket.set(zmq.SNDTIMEO, 20000)
        self.socket.connect(f"tcp://{self._host}:{self._port}")

    @timeout_decorator.timeout(seconds=ZmqClientConfig.CLIENT_TIMEOUT_SECONDS)
    def _send_request(self, data: Any) -> Any:
        """Sends the encoded data to the server and returns the raw server
        response

        Args:
            data: Encoded data to send to the server

        Returns:
            Raw response from the server (needs to be decoded using
            `self._serializer.decode_response()`)
        """
        try:
            self.socket.send(data)
            return self.socket.recv()
        except zmq.error.ZMQBaseError as zmq_error:
            if not ZmqClientConfig.SUPPRESS_ZMQ_ERRORS:
                raise zmq_error
            logger.info("Hit a connection error, exiting silently")
            sys.exit(0)

    @classmethod
    def builder(cls, env_name: str, **kwargs) -> ZeroMqClient:
        """Creates a new instance of the class

        The necessary values are read from environment and exception is raised
        in case of missing environment variables.

        Args:
            env_name: Name of the env to create
            kwargs: Additional options passed to `gym.make`

        Returns:
            A new instance of `ZeroMqClient`
        """
        from aicrowd_gym.serializers import MessagePackSerializer

        host = env_helpers.get_env(EnvConstants.SERVER_HOST)
        port = int(env_helpers.get_env(EnvConstants.SERVER_PORT))

        try:
            client = cls(
                host=host,
                port=port,
                env_name=env_name,
                env_config=kwargs,
                serializer=MessagePackSerializer(),
            )
            return client
        except zmq.error.ZMQBaseError:
            pass
        logger.error("Failed to create the gym client")
