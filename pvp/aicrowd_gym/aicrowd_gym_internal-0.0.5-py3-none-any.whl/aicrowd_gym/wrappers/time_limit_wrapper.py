#  Copyright (c) 2022. AIcrowd. All rights reserved.

import time

import gym
import numpy as np

from aicrowd_gym.core.wrapper import DelayAttributes
from aicrowd_gym.exceptions import PluginStopConditionMet
from aicrowd_gym.wrappers.throughput_wrapper import ThroughputCalculator


class TimeLimiter(ThroughputCalculator):
    """Implements per step and per env time limits

    This wrapper enforces per step and over all timeouts for an instance of the
    given environment.
    """

    def __init__(
        self,
        env: gym.Env,
        overall_timeout: int = 12 * 60 * 60,
        per_step_timeout: int = 10,
        warmup_time: int = 180,
    ):
        """Initialize the class

        Args:
            env: Gym environment
            overall_timeout: The time after which the environment should throw error
            per_step_timeout: The time after which the env.step calls should fail
            warmup_time: The time for which `per_step_timeout` can be violated
        """
        super(TimeLimiter, self).__init__(env)
        self._overall_timeout = overall_timeout
        self._per_step_throughput = 1 / per_step_timeout
        self._warmup_time = warmup_time
        self._warmup_start_time = np.inf

        try:
            self._timer = time.monotonic
        except AttributeError:
            self._timer = time.time

        self._start_time = self._timer()

    def step(self, action):
        observations = super().step(action)
        if self.throughput < self._per_step_throughput:
            if self._warmup_start_time == np.inf:
                self._warmup_start_time = self._timer()
        else:
            self._warmup_start_time = np.inf
        if self._timer() - self._warmup_start_time > self._warmup_time:
            print("Throughput", self.throughput)
            print("Target", self._per_step_throughput)
            raise PluginStopConditionMet("Current throughput is less than the required")
        return observations

    def _get_delay_for(self, attr: str):
        env_delay = getattr(self.env, attr, 0)
        client_delay = self.env.metadata.get(self._client_delay_key, {}).get(attr, 0)
        total_delay = client_delay - env_delay
        return total_delay

    def _get_overall_delay(self):
        return (
            self._get_delay_for(DelayAttributes.TOTAL_PER_STEP_DELAY)
            + self._get_delay_for(DelayAttributes.TOTAL_PER_RESET_DELAY)
            + self._get_delay_for(DelayAttributes.TOTAL_MISC_CALLS_DELAY)
        )

    def reset(self, **kwargs):
        observations = super().reset()
        if (
            self._timer() - self._start_time
            > self._overall_timeout + self._get_overall_delay()
        ):
            print("Adjusted timeout", self._overall_timeout + self._get_overall_delay())
            raise PluginStopConditionMet("Reached max allowed time")
        return observations
