#  Copyright (c) 2022. AIcrowd. All rights reserved.

import time

import gym

from aicrowd_gym.core.wrapper import DelayAttributes


class ThroughputCalculator(gym.Wrapper):
    def __init__(self, env):
        super(ThroughputCalculator, self).__init__(env)
        self.throughput = 0
        self.num_observations = 0
        self._client_delay_key = "aicrowd_client_delays"
        self._clock_started = False
        self._start_time = None
        try:
            self._timer = time.monotonic
        except AttributeError:
            self._timer = time.time

    def _get_throughput(self):
        elapsed_time = self._timer() - self._start_time
        throughput = self.num_observations / (elapsed_time - self._get_step_delay())
        self._wall_throughput = self.num_observations / elapsed_time
        return throughput

    def _get_step_delay(self):
        env_delay = getattr(self.env, DelayAttributes.TOTAL_PER_STEP_DELAY, 0)
        client_delay = self.env.metadata.get(self._client_delay_key, {}).get(
            DelayAttributes.TOTAL_PER_STEP_DELAY, 0
        )
        total_delay = client_delay - env_delay
        return total_delay

    def step(self, action):
        self.num_observations += 1
        if not self._clock_started:
            self._start_time = self._timer()
            self._clock_started = True

        self.throughput = self._get_throughput()
        return self.env.step(action)
