#  Copyright (c) 2022. AIcrowd. All rights reserved.

from typing import Any, Dict, List, Tuple, Union

from aicrowd_gym.constants import StatusOptions


class BaseSerializer:
    EVENT_NAME_KEY = "event"
    EVENT_STATUS_KEY = "status"
    STATUS_MESSAGE_KEY = "message"
    DATA_KEY = "data"
    INSTANCE_ID_KEY = "instance_id"
    SERVICE_ACTION_KEY = "service_action"
    TARGET_ATTRIBUTE_KEY = "target_attribute"
    ARGS_KEY = "args"
    KWARGS_KEY = "kwargs"
    CLIENT_DELAY_STATS = "client_delay_stats"

    def raw_encode(self, data: Any) -> Any:
        raise NotImplementedError

    def encode_response(
        self,
        # event_name: str,
        data: Any,
        status: str = StatusOptions.SUCCESS,
        message: str = StatusOptions.SUCCESS,
    ) -> Any:
        return self.raw_encode(
            {
                # self.EVENT_NAME_KEY: event_name,
                self.DATA_KEY: data,
                self.EVENT_STATUS_KEY: status,
                self.STATUS_MESSAGE_KEY: message,
            }
        )

    def encode_request(
        self,
        instance_id: str,
        service_action: str,
        target_attribute: str = None,
        args: Union[List[Any], Tuple[Any]] = None,
        kwargs: Dict[str, Any] = None,
        client_delay_stats: Dict[str, float] = None,
    ):
        return self.raw_encode(
            {
                self.INSTANCE_ID_KEY: instance_id,
                self.SERVICE_ACTION_KEY: service_action,
                self.TARGET_ATTRIBUTE_KEY: target_attribute,
                self.ARGS_KEY: args,
                self.KWARGS_KEY: kwargs,
                self.CLIENT_DELAY_STATS: client_delay_stats,
            }
        )

    def raw_decode(self, data: Any) -> Any:
        raise NotImplementedError

    def decode_response(self, data: Any) -> Tuple[Any, str, str]:
        deserialized_data = self.raw_decode(data)
        return (
            # deserialized_data.get(self.EVENT_NAME_KEY),
            deserialized_data.get(self.DATA_KEY),
            deserialized_data.get(self.EVENT_STATUS_KEY, StatusOptions.FAILED),
            deserialized_data.get(self.STATUS_MESSAGE_KEY),
        )

    def decode_request(
        self, data: Any
    ) -> Tuple[str, str, str, List[str], Dict[str, Any], Dict[str, float]]:
        request = self.raw_decode(data)
        return (
            request[self.INSTANCE_ID_KEY],
            request[self.SERVICE_ACTION_KEY],
            request[self.TARGET_ATTRIBUTE_KEY],
            request[self.ARGS_KEY],
            request[self.KWARGS_KEY],
            request[self.CLIENT_DELAY_STATS],
        )
