#  Copyright (c) 2022. AIcrowd. All rights reserved.

from typing import Any

import msgpack
import msgpack_numpy as m

from aicrowd_gym.serializers.base import BaseSerializer

m.patch()


class MessagePackSerializer(BaseSerializer):
    """Serializer to convert python objects to message pack binary format"""

    def __init__(self):
        self.content_type = "application/octet-stream"

    def raw_encode(self, data: Any) -> bytes:
        return msgpack.packb(data)

    def raw_decode(self, data: bytes) -> Any:
        return msgpack.unpackb(data)
