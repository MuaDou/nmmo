#  Copyright (c) 2022. AIcrowd. All rights reserved.

import json
from importlib import import_module
from typing import Any

import numpy as np
from loguru import logger

from aicrowd_gym.serializers.base import BaseSerializer


class NumpyEncoder(json.JSONEncoder):
    """Extends default JSON encoder to handle numpy objects."""

    def default(self, obj):
        """Override the default behaviour of `JSONEncoder`"""
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return json.JSONEncoder.default(self, obj)


class JsonSerializer(BaseSerializer):
    """Serializer to convert python objects to JSON compatible strings.

    The serializer tries to use `orjson` if it is installed and falls backs to
    the python's default json package if it is not available.
    """

    def __init__(self):
        self.content_type = "application/json"
        self.base_encoding_module = None
        self.encoder = None
        self._setup_base_encoder()

    def _setup_base_encoder(self):
        try:
            self.base_encoding_module = import_module("orjson.json")
            self.encoder = lambda x: self.base_encoding_module.dumps(
                x, option=self.base_encoding_module.OPT_SERIALIZE_NUMPY
            )
        except ImportError:
            logger.info("Install `orjson` for better performance")
            self.base_encoding_module = import_module("json")
            self.encoder = lambda x: self.base_encoding_module.dumps(
                x, cls=NumpyEncoder
            )

    def raw_encode(self, data: Any) -> str:
        return self.encoder(data)

    def raw_decode(self, data: str) -> Any:
        return self.base_encoding_module.loads(data)
