#  Copyright (c) 2022. AIcrowd. All rights reserved.

from typing import Any, Callable, Dict

import gym

from aicrowd_gym.plugins.base import BaseGymPlugin


class EnvWrapperAdder(BaseGymPlugin):
    """Plugin to add a `gym.Wrapper` to all the environments that are created
    on the server.

    Examples:
        Say we want to add the `VideoRecorder` gym wrapper to all the
        environments that are created on the server. The following snippet
        accomplishes this.

        ```python
        import gym

        env_wrapper_fn = lambda x: gym.wrappers.Monitor(env=x, directory="videos")
        wrapper_adder = EnvWrapperAdder(env_wrapper_fn=env_wrapper_fn)

        server = ZeroMqServer(plugins=[wrapper_adder])
        ```
    """

    def __init__(self, env_wrapper_fn: Callable):
        self.wrapper_builder = env_wrapper_fn

    def post_env_create(
        self, instance_id: str, env: gym.Env, env_name: str, env_config: Dict[str, Any]
    ) -> gym.Env:
        """ """
        return self.wrapper_builder(env)
