#  Copyright (c) 2022. AIcrowd. All rights reserved.

import time
import uuid
from typing import Any, Dict, Tuple

import gym

from aicrowd_gym.plugins.base import BaseGymPlugin
from aicrowd_gym.serializers.json import JsonSerializer


class RewardsRecorder(BaseGymPlugin):
    """Plugin to record the per episode and cumulative rewards from the
    environments on the server.

    Examples:
        Consider the following snippet of code.

        ```python
        rewards_recorder = RewardsRecorder("rewards.json")
        server = ZeroMqServer(plugins=[rewards_recorder])
        ```

        This will collect the rewards for every episode and write them to
        `rewards.json` file. The rewards are dumped to the disk after
        completing an episode.
    """

    def __init__(self, rewards_file: str, record_steps: bool = True):
        """Initialize the plugin

        Args:
            rewards_file: Path to the file on disk where the rewards will be stored
        """
        self.rewards_file = rewards_file
        self.record_steps = record_steps
        self.current_episode_rewards = {}
        self.episode_rewards = []
        self.episode_summary = {}
        self.serializer = JsonSerializer()

    def write_rewards_to_disk(self):
        """Dumps the rewards collected so far to the disk"""
        stats = {
            "episode_rewards": self.episode_rewards,
            "cumulative_reward": sum(self.episode_rewards),
            "episode_summary": self.episode_summary,
        }
        with open(self.rewards_file, "w") as fp:
            fp.write(self.serializer.raw_encode(stats))

    def post_env_create(
        self, instance_id: str, env: gym.Env, env_name: str, env_config: Dict[str, Any]
    ) -> gym.Env:
        """ """
        self.current_episode_rewards[instance_id] = 0
        return env

    def post_env_reset(
        self, instance_id: str, env: gym.Env, observations: Any
    ) -> Tuple[gym.Env, Any]:
        env.aicrowd_episode_id = str(uuid.uuid4())
        env.aicrowd_episode_start_time = time.time()
        self.episode_summary[env.aicrowd_episode_id] = {
            "start_time": env.aicrowd_episode_start_time,
            "steps": [],
        }
        return env, observations

    def post_env_step(
        self, instance_id: str, env: gym.Env, action: Any, observations: Any
    ) -> Tuple[gym.Env, Any]:
        """ """
        _, reward, done, _ = observations
        self.current_episode_rewards[instance_id] += reward
        step_summary = {
            "time": time.time(),
            "reward": reward,
        }
        if self.record_steps:
            step_summary["action"] = action
            step_summary["observations"] = observations
        self.episode_summary[env.aicrowd_episode_id]["steps"].append(step_summary)
        if done:
            self.episode_rewards.append(self.current_episode_rewards[instance_id])
            self.episode_summary[env.aicrowd_episode_id]["end_time"] = time.time()
            self.episode_summary["total_reward"] = self.current_episode_rewards[
                instance_id
            ]
            self.current_episode_rewards[instance_id] = 0
            self.write_rewards_to_disk()
        return env, observations
