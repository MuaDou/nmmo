#  Copyright (c) 2022. AIcrowd. All rights reserved.

import time
from typing import Any, Tuple

import gym
import numpy as np
from loguru import logger

from aicrowd_gym.exceptions import PluginStopConditionMet
from aicrowd_gym.plugins.throughput_calculator import ThroughputCalculator


class ThroughputCutOff(ThroughputCalculator):
    """Plugin to limit stop the server if a target throughput is attained.

    Examples:
        Say, the client code should consume environment steps at
        `1000 timesteps/second`. The following snippet of code will handle this
        use case.

        ```python
        cutoff_plugin = ThroughputCutOff(target_throughput=1000)
        server = ZeroMqServer(plugins=[cutoff_plugin])
        ```

        This plugin can also be used to limit the total time the server is
        active, i.e., the total time the rollouts can run for. Say, we want to
        limit the total running time for rollouts to 2 hours, then

        ```python
        cutoff_plugin = Throughput(target_throughput=1000, overall_timeout=2*60*60)
        ```
    """

    def __init__(
        self, target_throughput: int, overall_timeout: int, warmup_time: int = 300
    ):
        """Initialize the class

        Args:
            target_throughput: Minimum throughput needed
            overall_timeout: The time after which the server should stop
            warmup_time: The time for which `target_throughput` condition can
                            be violated
        """
        super(ThroughputCutOff, self).__init__()
        self.target_throughput = target_throughput
        self.overall_timeout = overall_timeout
        self.warmup_time = warmup_time
        self.warmup_start_time = np.inf
        self.start_time = time.time()

    def post_env_step(
        self, instance_id: str, env: gym.Env, action: Any, observations: Any
    ) -> Tuple[gym.Env, Any]:
        """ """
        super().post_env_step(
            instance_id=instance_id, env=env, action=action, observations=observations
        )

        if self.throughput < self.target_throughput:
            if self.warmup_start_time == np.inf:
                logger.debug("starting warm up time")
                self.warmup_start_time = time.time()
        else:
            logger.debug(
                "resetting warm up time throughput: {}, target: {}",
                self.throughput,
                self.target_throughput,
            )
            self.warmup_start_time = np.inf

        if time.time() - self.warmup_start_time > self.warmup_time:
            raise PluginStopConditionMet("Current throughput is less than the target")
        return env, observations

    def post_env_reset(
        self, instance_id: str, env: gym.Env, observations: Any
    ) -> Tuple[gym.Env, Any]:
        """ """
        if time.time() - self.start_time > self.overall_timeout:
            raise PluginStopConditionMet("Reached max allowed time")
        return env, observations
