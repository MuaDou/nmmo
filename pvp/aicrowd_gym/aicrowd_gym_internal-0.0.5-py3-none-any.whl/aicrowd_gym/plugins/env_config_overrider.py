#  Copyright (c) 2022. AIcrowd. All rights reserved.

from typing import Any, Dict, Tuple

from aicrowd_gym.plugins.base import BaseGymPlugin


class EnvConfigOverrider(BaseGymPlugin):
    """Plugin to override the config options passed during gym environment
    creation

    Examples:
        If we want to make sure that all the environments that are created
        on the server are always `CartPole-v0` environments,

        ```python
        overrider = EnvConfigOverrider(env_name="CartPole-v0")
        server = ZeroMqServer(plugins=[overrider])
        ```

        Say for example, we have the following environment.

        ```python
        env = gym.make("procgen:procgen-coinrun-v0", center_agent=True)
        ```

        If we want to make sure that `center_agent` is always set to `True`
        irrespective of the client side configuration,

        ```python
        overrider = EnvConfigOverrider(config={"center_agent": True})
        ```

        Setting `merge_config` to `False` will completely drop the config
        options passed from the client side.
    """

    def __init__(
        self,
        env_name: str = None,
        config: Dict[str, Any] = None,
        merge_config: bool = True,
    ):
        """Initialize the class

        Args:
            env_name: If a value is set, all the environments created on the
                        server will always have this name
            config: If a value is set, the dictionary values are used to
                        override the environment creation options
            merge_config: If set to `False`, the environment config options
                        passed from the client are ignored.
        """
        self.env_name = env_name
        self.config = config
        self.merge_config = merge_config

    def pre_env_create(
        self, instance_id: str, env_name: str, env_config: Dict[str, Any]
    ) -> Tuple[str, Dict[str, Any]]:
        """ """
        if self.env_name:
            env_name = self.env_name
        if self.config:
            if self.merge_config:
                env_config = {**env_config, **self.config}
            else:
                env_config = self.config
        return env_name, env_config
