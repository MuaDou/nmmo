#  Copyright (c) 2022. AIcrowd. All rights reserved.

from typing import Any, Dict, Tuple

import gym


class BaseGymPlugin:
    """Base gym plugin class that needs to be used to create new plugins"""

    def pre_env_reset(self, instance_id: str, env: gym.Env) -> gym.Env:
        """Hook triggered before executing `env.reset()`

        Args:
            instance_id: ID of the gym environment on the server
            env: Gym environment on which the action is invoked

        Returns:
            The gym environment on which the action is invoked
        """
        return env

    def post_env_reset(
        self, instance_id: str, env: gym.Env, observations: Any
    ) -> Tuple[gym.Env, Any]:
        """Hook triggered after executing `env.reset()`

        Args:
            instance_id: ID of the gym environment on the server
            env: Gym environment on which the action is invoked
            observations: Outputs from `env.reset()`

        Returns:
            The gym environment on which the action is invoked and
            the observations obtained from `env.reset()`. The observations
            returned here will be passed to the client.
        """
        return env, observations

    def pre_env_step(
        self, instance_id: str, env: gym.Env, action: Any
    ) -> Tuple[gym.Env, Any]:
        """Hook triggered before executing `env.step()`

        Args:
            instance_id: ID of the gym environment on the server
            env: Gym environment on which the action is invoked
            action: Action that is passed to `env.step()`

        Returns:
            The gym environment on which the action is invoked and the action
            that needs to be passed to `env.step()`.
        """
        return env, action

    def post_env_step(
        self, instance_id: str, env: gym.Env, action: Any, observations: Any
    ) -> Tuple[gym.Env, Any]:
        """Hook triggered after executing `env.step()`

        Args:
            instance_id: ID of the gym environment on the server
            env: Gym environment on which the action is invoked
            action: Action that is passed to `env.step()`
            observations: Outputs from `env.step(action)`

        Returns:
            The gym environment on which the action is invoked and the
            observations obtained from `env.step(action)` The observations
            returned here will be passed to the client.
        """
        return env, observations

    def pre_env_create(
        self,
        instance_id: str,
        env_name: str,
        env_config: Dict[str, Any],
    ) -> Tuple[str, Dict[str, Any]]:
        """Hook triggered before creating an environment

        Args:
            instance_id: ID of the gym environment on the server
            env_name: Name of the environment that is to be created
            env_config: Configuration passed to `gym.make`

        Returns:
            The modified `env_name` and `env_config`.
        """
        return env_name, env_config

    def post_env_create(
        self, instance_id: str, env: gym.Env, env_name: str, env_config: Dict[str, Any]
    ) -> gym.Env:
        """Hook triggered after creating an environment

        Args:
            instance_id: ID of the gym environment created on the server
            env: Gym environment that is created
            env_name: Name of the environment that is to be created
            env_config: Configuration passed to `gym.make`

        Returns:
            The gym environment that needs to be passed to the client.
        """
        return env
