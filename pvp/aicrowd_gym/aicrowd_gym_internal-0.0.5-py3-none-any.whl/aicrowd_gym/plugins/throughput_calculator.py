#  Copyright (c) 2022. AIcrowd. All rights reserved.

import time
from typing import Any, Tuple

import gym

from aicrowd_gym.plugins.base import BaseGymPlugin


class ThroughputCalculator(BaseGymPlugin):
    """Plugin to calculate the throughput of the time steps being consumed by
    the client.

    Examples:
        To use the plugin,

        ```python
        throughput_calculator = ThroughputCalculator()
        server = ZeroMqServer(plugins=[throughput_calculator])
        ```
    """

    def __init__(self, num_observations: int = 500, historical_weight: float = 0.3):
        """Initialize the plugin

        Args:
            num_observations: Number of observations (time steps counter) to
                                use to calculate the throughput
            historical_weight: The weight to be assigned to old throughput when
                                calculating weighted throughput
        """
        self.last_n_records = []
        self.last_recorded_time = 0
        self.weighted_throughput = 0
        self.throughput = 0
        self.num_observations = num_observations
        self.weight = historical_weight

    def _get_throughput(self):
        past_rate_samples = []
        for i in range(1, len(self.last_n_records)):
            past_rate_samples.append(
                self.last_n_records[i] - self.last_n_records[i - 1]
            )
        return len(past_rate_samples) / sum(past_rate_samples)

    def _record_current_timestamp(self):
        current_time = time.time()
        self.last_n_records.append(current_time)

        if len(self.last_n_records) > self.num_observations:
            del self.last_n_records[0]

        return current_time

    def post_env_step(
        self, instance_id: str, env: gym.Env, action: Any, observations: Any
    ) -> Tuple[gym.Env, Any]:
        """ """
        current_time = self._record_current_timestamp()
        if self.last_recorded_time == 0:
            self.last_recorded_time = current_time
            return env, observations

        self.throughput = self._get_throughput()
        self.weighted_throughput = (
            self.weight * self.weighted_throughput + (1 - self.weight) * self.throughput
        )
        return env, observations
