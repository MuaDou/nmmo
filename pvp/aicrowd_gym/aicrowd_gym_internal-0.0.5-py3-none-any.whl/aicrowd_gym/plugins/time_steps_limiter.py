#  Copyright (c) 2022. AIcrowd. All rights reserved.

from typing import Any, Dict, Tuple

import gym
import numpy as np
from loguru import logger

from aicrowd_gym.exceptions import PluginStopConditionMet
from aicrowd_gym.plugins.base import BaseGymPlugin


class EpisodeLimitModes:
    FIRST_IN = "first_in"
    FIRST_OUT = "first_out"


class TimeStepsBudgetLimiter(BaseGymPlugin):
    """Plugin to limit the maximum number of time steps or episodes that can be
    consumed.

    Note:
        The plugin will stop the evaluation after completion of an episode. For
        example, say, the maximum number of time steps allowed is 1000. The
        count of time steps before the start of the episode is 999 and let's
        say that the episode length will always be 333. The plugin will halt
        the evaluation after 999 + 333 steps and not after 1000 steps.

    Examples:
        Say, we want to limit the maximum number of rollout episode to 1000.
        The plugin can be initialized using

        ```python
        episode_limiter = TimeStepsBudgetLimiter(
            max_episodes=1000,
            max_time_steps=10e10
        )
        ```

        Note that the `max_time_steps` is set to a large value so that it
        doesn't effect the episode count.

        To limit the total time steps to 8 million, you can do the following

        ```python
        time_steps_limiter = TimeStepsBudgetLimiter(max_time_steps=8e10)
        ```
    """

    def __init__(
        self,
        max_time_steps: int,
        max_episodes: int = None,
        episode_limit_mode: str = EpisodeLimitModes.FIRST_IN,
        skip_initial_reset: bool = True,
    ):
        """Initialize the class

        Args:
            max_time_steps: Maximum number of time steps to run the evaluation for
            max_episodes: Maximum number of episodes to run the evaluation for
            episode_limit_mode: Should be one of `EpisodeLimitModes.FIRST_IN`
                or `EpisodeLimitModes.FIRST_OUT`. `FIRST_IN` tracks the first
                `max_episodes` episodes and waits for them to complete.
                `FIRST_OUT` stops the evaluation as soon as `max_episodes`
                complete.
            skip_initial_reset: Ignore the `env.reset` called when the environment
                is created from the current episode count
        """
        self.max_time_steps = max_time_steps
        self.skip_initial_reset = skip_initial_reset
        if max_episodes is None:
            max_episodes = np.inf
        self.max_episodes = max_episodes
        self.episode_limit_mode = episode_limit_mode
        self._current_time_steps = 0
        self._current_episode_count = 0
        self.target_episode_ids = set()
        self.completed_episode_ids = set()

    def post_env_create(
        self, instance_id: str, env: gym.Env, env_name: str, env_config: Dict[str, Any]
    ) -> gym.Env:
        """ """
        if self.skip_initial_reset:
            self._current_episode_count -= (
                1  # Do not count the initial reset needed for env
            )
        return env

    def post_env_step(
        self, instance_id: str, env: gym.Env, action: Any, observations: Any
    ) -> Tuple[gym.Env, Any]:
        """ """
        self._current_time_steps += 1
        return env, observations

    def post_env_reset(
        self, instance_id: str, env: gym.Env, observations: Any
    ) -> Tuple[gym.Env, Any]:
        """ """
        self._current_episode_count += 1
        if self._current_time_steps > self.max_time_steps:
            logger.info(
                "Number of time steps: {} > max allowed: {}",
                self._current_time_steps,
                self.max_time_steps,
            )
            raise PluginStopConditionMet("Reached max time steps allowed")
        if self._current_episode_count > self.max_episodes:
            logger.info(
                "Number of episodes: {} > max allowed: {}",
                self._current_episode_count,
                self.max_episodes,
            )
            raise PluginStopConditionMet("Reached max episodes allowed")
        return env, observations
