#  Copyright (c) 2022. AIcrowd. All rights reserved.

from __future__ import annotations

from typing import Any, Dict, Union

import zmq
from loguru import logger

from aicrowd_gym.serializers.base import BaseSerializer
from aicrowd_gym.servers.base_agent import Agent


class ZmqAgent(Agent):
    """ZeroMQ client for agent server to send commands and receive responses
    from agent server running on the client side.

    This is used by `ZmqOracleServer`.
    """

    context: zmq.Context
    socket: zmq.Socket

    def __init__(
        self,
        host: str,
        port: Union[str, int],
        server_id: str,
        serializer: BaseSerializer,
        metadata: Dict = None,
        receive_timeout: int = 6000000,
    ):
        """Initialize ZeroMQ agent server.

        Args:
            host: Hostname or IP address of the agent server to connect to.
            port: Port on which agent server is running.
            server_id: Server ID for the agent.
            serializer: Serializer to decode and encode the data between agent
                and oracle.
            metadata: Additional metadata for the agent.
            receive_timeout: ZMQ socket timeout.
        """
        super(ZmqAgent, self).__init__(
            server_id=server_id, serializer=serializer, metadata=metadata
        )
        logger.info("Initializing client with ID: {}", server_id)
        self.host = host
        self.port = port
        self.id = server_id
        self.init_zmq_socket(host, int(port), receive_timeout)
        self.receive_timeout = receive_timeout
        self.request_counter = 0

    def init_zmq_socket(self, host: str, port: int, receive_timeout: int):
        """Initialize ZMQ sockets.

        Args:
            host: Hostname or IP address of the agent server.
            port: Port on which the agent server runs.
            receive_timeout: ZMQ socket timeout.
        """
        logger.info("Initializing socket for agent: {}", self.id)
        self.context = zmq.Context.instance()
        self.socket = self.context.socket(zmq.DEALER)
        self.socket.setsockopt(zmq.RCVTIMEO, receive_timeout)
        self.socket.connect("tcp://{}:{}".format(host, port))
        self.responses = {}

    def _send_request(self, data: Any):
        """Send encoded data (command with args and kwargs) to the agent
        server.

        Args:
            data: Encoded data to send to the agent server.
        """
        self.socket.send(b"", zmq.SNDMORE)
        self.socket.send(data, flags=zmq.NOBLOCK)

    def _wait_for_reply(self, default_value: Any = None, timeout: int = None) -> Any:
        """Wait for a reply from agent server with a timeout.

        Args:
            default_value: Default value to return if no response is received
                from agent server within the specified timeout.
            timeout: Timeout to receive the response from agent server.

        Returns:
            Encoded data from the agent server.
        """
        logger.debug("Waiting for a reply...")
        if timeout is not None:
            self.socket.setsockopt(zmq.RCVTIMEO, timeout)
        else:
            self.socket.setsockopt(zmq.RCVTIMEO, self.receive_timeout)
        try:
            if self.socket.recv() == b"":
                return self.socket.recv()
            return self.socket.recv()
        except zmq.error.Again:
            return default_value

    @classmethod
    def from_json(cls, payload: Dict[str, Any], serializer: BaseSerializer) -> ZmqAgent:
        """Helper class method to create new proxy agent object.

        Args:
            payload: Dictionary containing `host`, `port`, `id`, `metadata` of
                the agent server.
            serializer: Serializer to decode and encode data between agent and
                oracle.

        Returns:
            `ZmqAgent` remote proxy object for the agent server.
        """
        return cls(
            host=payload["host"],
            port=payload["port"],
            server_id=payload["id"],
            metadata=payload["metadata"],
            serializer=serializer,
        )
