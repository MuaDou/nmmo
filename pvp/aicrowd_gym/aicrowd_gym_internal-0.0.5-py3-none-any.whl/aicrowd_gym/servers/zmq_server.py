#  Copyright (c) 2022. AIcrowd. All rights reserved.

from typing import List

import zmq
from loguru import logger

from aicrowd_gym.plugins.base import BaseGymPlugin
from aicrowd_gym.serializers.base import BaseSerializer
from aicrowd_gym.servers.base import BaseGymServer


class ZeroMqServer(BaseGymServer):
    """ """

    def __init__(
        self,
        serializer: BaseSerializer,
        host: str = "0.0.0.0",
        port: int = 5000,
        plugins: List[BaseGymPlugin] = None,
        action_space_callables: List[str] = None,
        observation_space_callables: List[str] = None,
        env_attributes: List[str] = None,
    ):
        self.host = host
        self.port = port
        self.serializer = serializer
        self._exit_server = False
        self._init_socket()
        super().__init__(
            plugins=plugins,
            action_space_callables=action_space_callables,
            observation_space_callables=observation_space_callables,
            env_attributes=env_attributes,
        )

    def _init_socket(self):
        logger.debug("Initializing zmq socket")
        self.context = zmq.Context.instance()
        self.socket = self.context.socket(zmq.REP)
        self.socket.set(zmq.SNDTIMEO, 2000)
        self.socket.bind(f"tcp://{self.host}:{self.port}")

    def _run_server(self):
        while not self._exit_server:
            message = self.socket.recv()
            (
                instance_id,
                service_action,
                child,
                args,
                kwargs,
                client_delays,
            ) = self.serializer.decode_request(data=message)
            raw_response, status, message = self.process_request(
                instance_id=instance_id,
                service_action=service_action,
                env_child_attribute=child,
                args=args,
                kwargs=kwargs,
                client_delays=client_delays,
            )
            response = self.serializer.encode_response(
                data=raw_response, status=status, message=message
            )
            self.socket.send(response)

    def run(self):
        try:
            self._run_server()
        except zmq.error.ZMQError as e:
            logger.error(f"{e}")
            raise e
