#  Copyright (c) 2022. AIcrowd. All rights reserved.


class EnvServiceActions:
    """Actions supported for env proxy objects."""

    ENV_CREATE = "create"
    ENV_RESET = "reset"
    ENV_STEP = "step"
    ENV_CLOSE = "close"
    ENV_ATTRIBUTE = "env_attribute"
    ENV_ACTION_SPACE = "action_space"
    ENV_OBSERVATION_SPACE = "observation_space"
    ENV_LIST = "list"


class AgentServiceActions:
    """Actions supported for oracle server-client interactions."""

    PING = "ping"
    REGISTER_CLIENT = "register_client"
    EXECUTE_CLIENT_METHOD = "execute_client_method"
    STOP_CLIENT = "stop_client"
