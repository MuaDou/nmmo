#  Copyright (c) 2022. AIcrowd. All rights reserved.

import uuid
from typing import Any, Dict, List, Type

from loguru import logger

from aicrowd_gym.constants import StatusOptions
from aicrowd_gym.serializers.base import BaseSerializer
from aicrowd_gym.servers.base_actions import AgentServiceActions
from aicrowd_gym.servers.base_agent import Agent


class BaseOracleServer:
    """Base oracle server class."""

    def __init__(
        self,
        num_agent_connections: int,
        serializer: BaseSerializer,
        agent_cls: Type[Agent] = None,
    ):
        """Initialize the base oracle server.

        Args:
            num_agent_connections: Expected number of agents to connect.
            serializer: Serializer to decode and encode data between client
                and server.
            agent_cls: The proxy agent class to use.
        """
        self.num_agent_connections = num_agent_connections
        self.serializer = serializer

        if agent_cls is None:
            raise ValueError("agent_cls should be specified")
        self.agent_cls = agent_cls

        self.agents = {}
        self.server_id = str(uuid.uuid4())

    def _send_data(self, data: Any) -> Any:
        """Send data to the oracle client. This should be a blocking call.

        Args:
            data: Encoded data that should be sent to oracle client.
        """
        raise NotImplementedError

    def _recv_data(self) -> Any:
        """Receive data from the oracle client. This should be a blocking call.

        Returns:
            Encoded data from the oracle client.
        """
        raise NotImplementedError

    def wait_for_agents(self):
        """Waits for all the agents to connect the oracle."""
        logger.info("Waiting for agents...")
        while len(self.agents) < self.num_agent_connections:
            raw_request = self._recv_data()
            (
                instance_id,
                action,
                target,
                args,
                kwargs,
                client_delays,
            ) = self.serializer.decode_request(raw_request)
            response = self.route_request(
                action=action,
                target_attribute=target,
                instance_id=instance_id,
                args=args,
                kwargs=kwargs,
            )
            payload = self.serializer.encode_response(
                data=response, status=StatusOptions.SUCCESS, message=""
            )
            self._send_data(payload)
        logger.success("Got connections from all agents!")

    def route_request(
        self,
        action: str,
        target_attribute: str,
        instance_id: str,
        args: List[Any],
        kwargs: Dict[str, Any],
    ):
        """Routes the requests from oracle client.

        Args:
            action: Action to execute. Should be one of `AgentServiceActions`.
            target_attribute: Additional attribute parameters (not used).
            instance_id: Server ID or request ID.
            args: Additional list of arguments to use.
            kwargs: Additional dict of arguments to use.

        Returns:
            The return value of the `action`.
        """
        if action == AgentServiceActions.REGISTER_CLIENT:
            return self.register_agent(kwargs)
        raise NotImplementedError

    def close_agents(self):
        """Stop all the connected agents."""
        logger.info("Shutting down all agents...")
        for agent in self.agents.values():
            agent.stop_server()

    def register_agent(self, agent_data: Dict[str, str]) -> bool:
        """Register a new agent on the oracle.

        Args:
            agent_data: Dictionary containing `host`, `port` and `id` of the
                agent server.
        """
        logger.info("Register agent with {}", agent_data)
        agent = self.agent_cls.from_json(agent_data, self.serializer.__class__())
        self.agents[agent.id] = agent
        return True
