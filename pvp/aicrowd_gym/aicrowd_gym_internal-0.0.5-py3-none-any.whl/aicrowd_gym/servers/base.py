#  Copyright (c) 2022. AIcrowd. All rights reserved.

from typing import Any, Dict, List, Tuple

from loguru import logger

from aicrowd_gym.constants import StatusOptions
from aicrowd_gym.core.wrapper import GymWrapper
from aicrowd_gym.exceptions import PluginStopConditionMet
from aicrowd_gym.plugins.base import BaseGymPlugin
from aicrowd_gym.servers.base_actions import EnvServiceActions


class BaseGymServer:
    """Base gym server class

    This class starts the gym wrapper service and acts as a communication layer
    between the server and the client
    """

    def __init__(
        self,
        plugins: List[BaseGymPlugin] = None,
        env_attributes: List[str] = None,
        action_space_callables: List[str] = None,
        observation_space_callables: List[str] = None,
    ):
        """Initialize the server.

        Args:
            plugins: Server side plugins to use.
            env_attributes: List of allowed attributes on the `env`.
            action_space_callables: List of allowed attributes/methods on
                action_space.
            observation_space_callables: List of allowed attributes/methods on
                observation_space.
        """
        self.service = GymWrapper(
            plugins=plugins,
            env_attributes=env_attributes,
            action_space_callables=action_space_callables,
            observation_space_callables=observation_space_callables,
        )

    def process_request(
        self,
        service_action: str,
        env_child_attribute: str,
        instance_id: str,
        args: List[Any],
        kwargs: Dict[str, Any],
        client_delays: Dict[str, float],
    ) -> Tuple[Any, str, str]:
        """Routes the incoming request and returns a response

        Args:
            service_action: Target action to invoke
            env_child_attribute: Attribute
            instance_id: Identifier of the environment to operate on
            args: List of positional args to pass to the target action
            kwargs: Additional arguments to pass to the target action
            client_delays: Latencies on the client side

        Returns:
            The raw response data, status of the operation, error message if
            the operation failed
        """
        status = StatusOptions.SUCCESS
        message = ""
        response = None
        try:
            response = self._route_request(
                service_action,
                env_child_attribute,
                instance_id,
                args,
                kwargs,
                client_delays,
            )
        except PluginStopConditionMet as e:
            status = StatusOptions.STOPPED
            message = str(e)
            return response, status, message
        except Exception as e:
            logger.exception(e)
            status = StatusOptions.FAILED
            message = str(e)
        return response, status, message

    def _route_request(
        self,
        service_action: str,
        env_child_attribute: str,
        instance_id: str,
        args: List[Any],
        kwargs: Dict[str, Any],
        client_delays: Dict[str, float],
    ):
        if service_action == EnvServiceActions.ENV_CREATE:
            return self.service.create(*args, **kwargs)

        self.service.update_client_delays(instance_id=instance_id, delays=client_delays)
        if service_action == EnvServiceActions.ENV_RESET:
            return self.service.env_reset(instance_id=instance_id)
        if service_action == EnvServiceActions.ENV_STEP:
            return self.service.env_step(
                instance_id=instance_id, action=kwargs["action"]
            )
        if service_action == EnvServiceActions.ENV_ACTION_SPACE:
            return self.service.env_action_space_executor(
                instance_id=instance_id,
                method_name=env_child_attribute,
                *args,
                **kwargs
            )
        if service_action == EnvServiceActions.ENV_OBSERVATION_SPACE:
            return self.service.env_observation_space_executor(
                instance_id=instance_id,
                method_name=env_child_attribute,
                *args,
                **kwargs
            )
        if service_action == EnvServiceActions.ENV_CLOSE:
            return self.service.env_close(instance_id=instance_id)
        if service_action == EnvServiceActions.ENV_LIST:
            return self.service.envs.keys()
        if service_action == EnvServiceActions.ENV_ATTRIBUTE:
            return self.service.get_env_attribute(
                instance_id=instance_id, attr_name=kwargs["attribute_name"]
            )

    def run(self):
        raise NotImplementedError
