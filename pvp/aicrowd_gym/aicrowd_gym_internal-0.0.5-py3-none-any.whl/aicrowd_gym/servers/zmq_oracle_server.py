#  Copyright (c) 2022. AIcrowd. All rights reserved.

from typing import Any

import zmq

from aicrowd_gym.serializers.base import BaseSerializer
from aicrowd_gym.servers.base_oracle import BaseOracleServer
from aicrowd_gym.servers.zmq_agent_server import ZmqAgent


class ZmqOracleServer(BaseOracleServer):
    """ZeroMQ oracle server.

    Examples:
        >>> from aicrowd_gym.serializers import MessagePackSerializer
        >>> server = ZmqOracleServer(
        ...     num_agent_connections=1,
        ...     host="127.0.0.1",
        ...     port=5000,
        ...     serializer=MessagePackSerializer(),
        ... )
        >>> server.wait_for_agents()  # wait for agents to connect
        >>> server.agents  # Dictionary containing agent proxy objects
    """

    context: zmq.Context
    socket: zmq.Socket

    def __init__(
        self,
        host: str,
        port: int,
        num_agent_connections: int,
        serializer: BaseSerializer,
    ):
        """Initialize ZMQ oracle server.

        Args:
            host: Hostname or IP address to bind the server to.
            port: Port to bind the server to.
            num_agent_connections: Number of agent connections to expect. This
                does not include the reconnections. At this point, the
                reconnection logic is not yet implemented.
            serializer: Serializer to use to encode and decode data between the
                server and the clients.
        """
        super(ZmqOracleServer, self).__init__(
            num_agent_connections=num_agent_connections,
            serializer=serializer,
            agent_cls=ZmqAgent,
        )
        self.init_zmq_sockets(host, port)

    def init_zmq_sockets(self, host: str, port: int):
        """Initialize ZMQ sockets.

        Args:
            host: Hostname or IP address to bind the socket to.
            port: Port to bind the socket to.
        """
        self.context = zmq.Context.instance()
        self.socket = self.context.socket(zmq.REP)
        self.socket.bind("tcp://{}:{}".format(host, port))

    def _send_data(self, data: Any) -> Any:
        """Sends the encoded data to the clients.

        This is a blocking call.

        Args:
            data: Encoded data to send to the client.
        """
        self.socket.send(data)

    def _recv_data(self) -> Any:
        """Receive the encoded data from the clients.

        This is a blocking call.

        Returns:
            Encoded data received from the client.
        """
        return self.socket.recv()
