#  Copyright (c) 2022. AIcrowd. All rights reserved.

import time
import uuid
from typing import Any, Dict

from loguru import logger

from aicrowd_gym.constants import StatusOptions
from aicrowd_gym.serializers.base import BaseSerializer
from aicrowd_gym.servers.base_actions import AgentServiceActions


class Agent:
    """Remote proxy object for agent class."""

    id: str
    responses: Dict[str, Any]

    def __init__(
        self, server_id: str, serializer: BaseSerializer = None, metadata: Dict = None
    ):
        """Initialize the agent object.

        Args:
            server_id: ID of the server. This is same on client and server side.
            serializer: Serializer to decode and encode data between client
                and server.
        """
        self.id = server_id
        self.serializer = serializer
        self.metadata = metadata

    def process_response(self, data: Any):
        """Decode the raw data received from agent server.

        Args:
            data: Encoded response received from the agent server.

        Returns:
            Decoded response from the agent server.
        """
        response, status, message = self.serializer.decode_response(data)
        if status != StatusOptions.SUCCESS:
            raise ValueError(message)
        return response

    def is_alive(self):
        """Checks of the agent server is responding.

        Returns:
            The server ID of the agent server. This should be same as `self.id`.
        """
        logger.debug("Get ping for agent: {}", self.id)
        payload = self.serializer.encode_request(
            instance_id=self.id, service_action=AgentServiceActions.PING
        )
        self._send_request(payload)
        raw_response = self._wait_for_reply()
        return self.process_response(raw_response)

    def __getattr__(self, method: str):
        """Execute the methods on agent class using blocking calls. The
        response from the agent server is returned as the return value.

        Args:
            method: The target method to execute on the agent.

        Returns:
            Return value of the method from the agent.
        """
        logger.debug("Executing method {} with blocking call", method)

        def wrapper(*args, **kwargs):
            request_id = self.execute(method, *args, **kwargs)
            return self.get_response(request_id)

        return wrapper

    def new_request_id(self):
        return str(uuid.uuid4())

    def execute(self, method: str, *args, **kwargs):
        """Execute the methods on agent class using non blocking calls.

        Args:
            method: The target method to execute on the agent.
            args: Positional arguments passed to the the method.
            kwargs: Additional named arguments passed to the method.

        Returns:
            The request ID of the operation. This request ID can be used to
            get the response from the agent server using `self.get_response`.
        """
        logger.debug("Executing {}(*{}, **{})", method, args, kwargs)
        request_id = self.new_request_id()
        payload = self.serializer.encode_request(
            instance_id=request_id,
            service_action=AgentServiceActions.EXECUTE_CLIENT_METHOD,
            target_attribute=method,
            args=args,
            kwargs=kwargs,
        )
        self._send_request(payload)
        return request_id

    def stop_server(self):
        """Stops the agent server."""
        logger.info("Stopping server for agent: {}", self.id)
        payload = self.serializer.encode_request(
            instance_id=self.id,
            service_action=AgentServiceActions.STOP_CLIENT,
        )
        self._send_request(payload)

    def get_response(
        self, request_id: str, default_value: Any = None, timeout: int = 600000
    ):
        """Waits for and returns the response corresponding to give
        `request_id`.

        Args:
            request_id: The ID of the request for which the data needs to be
                fetched.
            default_value: Default value to return on timeout.
            timeout: Wait time for the response to arrive.

        Returns:
              The decoded response for the given `request_id`.
        """
        logger.debug("Waiting for response on request_id: {}", request_id)
        if request_id in self.responses:
            return self.responses.pop(request_id)

        start_time = time.time()
        default_value = self.serializer.encode_response(
            data=default_value,
            status=StatusOptions.SUCCESS,
            message="Returning default value",
        )

        while time.time() - start_time < timeout / 1000:
            raw_response = self._wait_for_reply(
                default_value=default_value, timeout=timeout
            )
            response = self.process_response(raw_response)
            logger.debug("Got response: {}", response)
            if default_value == raw_response:
                return response
            if response["id"] == request_id:
                return response["data"]
            if request_id is self.responses:
                return self.responses.pop(request_id)
            self.responses[response["id"]] = response["data"]

    def _send_request(self, data: Any):
        """Send data from oracle to agent server. This should be a non-blocking
        call.

        Args:
            data: Data that needs to be sent to agent server.
        """
        raise NotImplementedError

    def _wait_for_reply(self, default_value: Any = None, timeout: int = 300000):
        """Receive data from the agent server. This should be a blocking call.

        Args:
            default_value: Default value to return on timeout.
            timeout: Wait time for the response to arrive.

        Returns:
            Encoded data from the agent server.
        """
        raise NotImplementedError

    def to_json(self):
        return {
            "host": self.host,
            "port": self.port,
            "id": self.id,
        }

    @classmethod
    def from_json(cls, payload, serializer: BaseSerializer):
        """Creates a new instance of the proxy agent object. This is a helper
        function to create the agent objects when the oracle client sends the
        agent server details.

        Args:
            payload: A dict containing `host`, `port` and `id` of the agent
                server.
            serializer: Serializer to decode and encode data between client
                and server.
        """
        raise NotImplementedError
