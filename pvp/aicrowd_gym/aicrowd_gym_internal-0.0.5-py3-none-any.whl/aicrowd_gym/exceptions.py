#  Copyright (c) 2022. AIcrowd. All rights reserved.


class ClientNotFoundError(ImportError):
    pass


class PluginStopConditionMet(Exception):
    pass
