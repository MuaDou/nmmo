#  Copyright (c) 2022. AIcrowd. All rights reserved.


class EnvConstants:
    CLIENT_NAME = "AICROWD_REMOTE_CLIENT_NAME"
    SERVER_HOST = "AICROWD_REMOTE_SERVER_HOST"
    SERVER_PORT = "AICROWD_REMOTE_SERVER_PORT"


class StatusOptions:
    SUCCESS = "success"
    FAILED = "failed"
    STOPPED = "stopped"
