"""Module to interact with gym environments
"""
#  Copyright (c) 2022. AIcrowd. All rights reserved.

import threading
import time
import uuid
from typing import Any, Dict, List, Tuple

import gym
import numpy as np
import six
from loguru import logger

from aicrowd_gym.plugins.base import BaseGymPlugin

DEFAULT_ACTION_SPACE_CALLABLES = (
    "contains",
    "dtype",
    "sample",
    "shape",
    "n",
    "spaces",
)
DEFAULT_OBSERVATION_SPACE_CALLABLES = (
    "bounded_above",
    "bounded_below",
    "contains",
    "dtype",
    "high",
    "is_bounded",
    "low",
    "sample",
    "shape",
    "n",
    "spaces",
)
DEFAULT_ENV_ATTRIBUTES = ("reward_range", "spec", "metadata")


def time_call(
    total: str = None, previous: str = None, average: str = None, counter: str = None
):
    def _decorator(fn):
        def _wrapper(self, *args, **kwargs):
            start_time = self._timer()
            result = fn(self, *args, **kwargs)
            time_taken = self._timer() - start_time

            def update_thread_level_delays(attribute: str, sum_delays: bool = True):
                thread_delays = getattr(self, DelayAttributes.THREAD_LEVEL_DELAYS, {})
                thread_id = f"machine_id#{threading.get_native_id()}"

                if thread_id not in thread_delays:
                    thread_delays[thread_id] = {}

                if sum_delays and attribute in thread_delays[thread_id]:
                    thread_delays[thread_id][attribute] += time_taken
                else:
                    thread_delays[thread_id][attribute] = time_taken

            if total:
                setattr(self, total, getattr(self, total) + time_taken)
                update_thread_level_delays(total)

            if previous:
                setattr(self, previous, time_taken)
                update_thread_level_delays(previous, sum_delays=False)

            if total and average and counter:
                current_counter = getattr(self, counter, 0) + 1
                new_average = getattr(self, total) / current_counter
                setattr(self, average, new_average)
                setattr(self, counter, current_counter)

            return result

        return _wrapper

    return _decorator


def set_delay_attributes(self: object):
    setattr(self, DelayAttributes.TOTAL_PER_STEP_DELAY, 0)
    setattr(self, DelayAttributes.PREVIOUS_PER_STEP_DELAY, 0)
    setattr(self, DelayAttributes.AVERAGE_PER_STEP_DELAY, 0)
    setattr(self, DelayAttributes.TOTAL_STEPS, 0)

    setattr(self, DelayAttributes.TOTAL_PER_RESET_DELAY, 0)
    setattr(self, DelayAttributes.PREVIOUS_PER_RESET_DELAY, 0)
    setattr(self, DelayAttributes.AVERAGE_PER_RESET_DELAY, 0)
    setattr(self, DelayAttributes.TOTAL_RESETS, 0)

    setattr(self, DelayAttributes.TOTAL_MISC_CALLS_DELAY, 0)
    setattr(self, DelayAttributes.THREAD_LEVEL_DELAYS, {})

    try:
        self._timer = time.monotonic
    except AttributeError:
        self._timer = time.time


def summarize_delays(self: object):
    return {
        DelayAttributes.TOTAL_STEPS: getattr(self, DelayAttributes.TOTAL_STEPS),
        DelayAttributes.TOTAL_PER_STEP_DELAY: getattr(
            self, DelayAttributes.TOTAL_PER_STEP_DELAY
        ),
        DelayAttributes.PREVIOUS_PER_STEP_DELAY: getattr(
            self, DelayAttributes.PREVIOUS_PER_STEP_DELAY
        ),
        DelayAttributes.AVERAGE_PER_STEP_DELAY: getattr(
            self, DelayAttributes.AVERAGE_PER_STEP_DELAY
        ),
        DelayAttributes.TOTAL_PER_RESET_DELAY: getattr(
            self, DelayAttributes.TOTAL_PER_RESET_DELAY
        ),
        DelayAttributes.PREVIOUS_PER_RESET_DELAY: getattr(
            self, DelayAttributes.PREVIOUS_PER_RESET_DELAY
        ),
        DelayAttributes.AVERAGE_PER_RESET_DELAY: getattr(
            self, DelayAttributes.AVERAGE_PER_RESET_DELAY
        ),
        DelayAttributes.TOTAL_RESETS: getattr(self, DelayAttributes.TOTAL_RESETS),
        DelayAttributes.TOTAL_MISC_CALLS_DELAY: getattr(
            self, DelayAttributes.TOTAL_MISC_CALLS_DELAY
        ),
        DelayAttributes.THREAD_LEVEL_DELAYS: getattr(
            self, DelayAttributes.THREAD_LEVEL_DELAYS
        ),
    }


class DelayAttributes:
    PREVIOUS_PER_STEP_DELAY = "_previous_per_step_delay"
    TOTAL_PER_STEP_DELAY = "_total_per_step_delay"
    AVERAGE_PER_STEP_DELAY = "_average_per_step_delay"
    TOTAL_STEPS = "_total_steps"

    PREVIOUS_PER_RESET_DELAY = "_previous_per_reset_delay"
    TOTAL_PER_RESET_DELAY = "_total_per_reset_delay"
    AVERAGE_PER_RESET_DELAY = "_average_per_reset_delay"
    TOTAL_RESETS = "_total_resets"

    TOTAL_MISC_CALLS_DELAY = "_total_misc_calls_delay"
    AVERAGE_CALL_DELAY = "_average_call_delay"
    TOTAL_CALLS = "_total_calls"

    THREAD_LEVEL_DELAYS = "_thread_delays"


class GymWrapper:
    """Container and manager for gym envs created"""

    def __init__(
        self,
        action_space_callables: List[str] = DEFAULT_ACTION_SPACE_CALLABLES,
        observation_space_callables: List[str] = DEFAULT_OBSERVATION_SPACE_CALLABLES,
        env_attributes: List[str] = DEFAULT_ENV_ATTRIBUTES,
        plugins: List[BaseGymPlugin] = None,
    ):
        """Create a gym wrapper service.

        Args:
            action_space_callables: List of callables and properties allowed on
                `env.action_space`.
            observation_space_callables: List of callables and properties
                allowed on the `env.observation_space`.
            env_attributes: List of properties allowed on the `env`.
            plugins: List of plugins to use.
        """
        self.envs = {}
        set_delay_attributes(self)

        if action_space_callables is None:
            action_space_callables = DEFAULT_ACTION_SPACE_CALLABLES
        self._action_space_callables = action_space_callables

        if observation_space_callables is None:
            observation_space_callables = DEFAULT_OBSERVATION_SPACE_CALLABLES
        self._observation_space_callables = observation_space_callables

        if env_attributes is None:
            env_attributes = DEFAULT_ENV_ATTRIBUTES
        self._env_attributes = env_attributes

        logger.info(
            "Starting wrapper with allowed callables for "
            "action_space: {}, "
            "observation_space: {}",
            action_space_callables,
            observation_space_callables,
        )

        if plugins is None:
            plugins = []
        self.plugins = plugins

    # @middleware.create_env
    def create(self, env_name: str, env_config: Dict[str, Any]) -> str:
        """Create a gym env and return the uuid identifier

        Args:
            env_name: Name of the env to create
            env_config: Kwargs passed to `gym.make`

        Returns:
            A UUID that identifies the created env

        Examples:
            To create a simple carpole env
            ```python
            svc = GymWrapper()
            env_id = svc.create("CartPole-v0")
            ```

            To create coinrun from procgen
            ```python
            svc.create(
                "procgen:procgen-coinrun-v0",
                {"start_level": 0, "num_levels": 1}
            )
            ```

            This is equivalent to
            ```python
            gym.make("procgen:procgen-coinrun-v0", start_level=0, num_levels=1)
            ```
        """
        instance_id = str(uuid.uuid4())
        for hook in self.plugins:
            env_name, env_config = hook.pre_env_create(
                instance_id, env_name, env_config
            )
        logger.info("Creating env: {} with options: {}", env_name, env_config)
        env = gym.make(env_name, **env_config)
        for hook in self.plugins:
            env = hook.post_env_create(
                env=env,
                env_name=env_name,
                env_config=env_config,
                instance_id=instance_id,
            )
        self.envs[instance_id] = env
        return instance_id

    def get_env(self, instance_id: str) -> gym.Env:
        """Returns the gym env object from the server

        Args:
            instance_id: UUID that identifies an env

        Returns:
            Returns the gym environment corresponding to the UUID

        Raises:
            KeyError: If the given UUID doesn't match any existing envs
        """
        logger.debug("Getting env with {}", instance_id)
        if instance_id not in self.envs:
            raise KeyError("No gym environment with the key", instance_id)
        return self.envs[instance_id]

    @time_call(
        total=DelayAttributes.TOTAL_PER_RESET_DELAY,
        previous=DelayAttributes.PREVIOUS_PER_RESET_DELAY,
        average=DelayAttributes.AVERAGE_PER_RESET_DELAY,
        counter=DelayAttributes.TOTAL_RESETS,
    )
    def env_reset(self, instance_id: str) -> Tuple:
        """Resets a gym instance and returns the response

        Args:
            instance_id: UUID that identifies an env

        Returns:
            Observations from the environment
        """
        logger.debug("Resetting env: {}", instance_id)
        env = self.get_env(instance_id)
        for hook in self.plugins:
            env = hook.pre_env_reset(env=env, instance_id=instance_id)
        observations = env.reset()
        for hook in self.plugins:
            env, observations = hook.post_env_reset(
                env=env, observations=observations, instance_id=instance_id
            )
        self.envs[instance_id] = env
        return observations

    @staticmethod
    def _validate_action(action: Any) -> Any:
        """Validate of the user given action and convert the action to a numpy
        array

        Args:
            action: Action to execute on the environment

        Returns:
            Action cast as numpy array
        """
        if isinstance(action, six.integer_types + (dict,)):
            return action
        return np.array(action)

    @time_call(
        total=DelayAttributes.TOTAL_PER_STEP_DELAY,
        previous=DelayAttributes.PREVIOUS_PER_STEP_DELAY,
        average=DelayAttributes.AVERAGE_PER_STEP_DELAY,
        counter=DelayAttributes.TOTAL_STEPS,
    )
    def env_step(self, instance_id: str, action: Any) -> Tuple:
        """Executes env.step() with given action"""
        logger.debug("Executing action: {} for env: {}", action, instance_id)
        action = self._validate_action(action)
        env = self.get_env(instance_id)
        for hook in self.plugins:
            env, action = hook.pre_env_step(
                env=env, action=action, instance_id=instance_id
            )
        observations = env.step(action)
        for hook in self.plugins:
            env, observations = hook.post_env_step(
                env=env,
                action=action,
                observations=observations,
                instance_id=instance_id,
            )
        self.envs[instance_id] = env
        return observations

    @time_call(total=DelayAttributes.TOTAL_MISC_CALLS_DELAY)
    def env_action_space_executor(
        self, instance_id: str, method_name: str, *args, **kwargs
    ) -> Any:
        logger.debug(
            "Executing action space method: {} -> {} {}, env: {}",
            method_name,
            args,
            kwargs,
            instance_id,
        )
        result = self._execute_method(
            instance_id,
            self._action_space_callables,
            "action_space",
            method_name,
            *args,
            **kwargs,
        )
        return result

    def _execute_method(
        self,
        instance_id: str,
        allowed_attributes: List[str],
        space_selector: str,
        method_name: str,
        *args,
        **kwargs,
    ):
        if method_name not in allowed_attributes:
            raise NotImplementedError(f"env.{space_selector}.{method_name} not allowed")
        env = self.get_env(instance_id)
        env_space = getattr(env, space_selector)
        target_obj = getattr(env_space, method_name)
        if callable(target_obj):
            result = target_obj(*args, **kwargs)
        else:
            result = target_obj
        return result

    @time_call(total=DelayAttributes.TOTAL_MISC_CALLS_DELAY)
    def env_observation_space_executor(
        self, instance_id: str, method_name: str, *args, **kwargs
    ) -> Any:
        logger.debug(
            "Executing observation space method: {} -> {} {}, env: {}".format(
                method_name, args, kwargs, instance_id
            )
        )
        result = self._execute_method(
            instance_id,
            self._observation_space_callables,
            "observation_space",
            method_name,
            *args,
            **kwargs,
        )
        return result

    @time_call(total=DelayAttributes.TOTAL_MISC_CALLS_DELAY)
    def get_env_attribute(self, instance_id: str, attr_name: str):
        logger.debug("Getting env attribute {} for env: {}", attr_name, instance_id)
        if attr_name not in self._env_attributes:
            raise AttributeError("Not allowed to access {}".format(attr_name))
        env = self.get_env(instance_id)
        return getattr(env, attr_name)

    @time_call(total=DelayAttributes.TOTAL_MISC_CALLS_DELAY)
    def env_close(self, instance_id: str):
        env = self.get_env(instance_id)
        env.close()
        self.envs.pop(instance_id)

    @time_call(total=DelayAttributes.TOTAL_MISC_CALLS_DELAY)
    def env_reward_range(self, instance_id: str):
        env = self.get_env(instance_id)
        env.reward_range()
        self.envs.pop(instance_id)

    def update_client_delays(self, instance_id: str, delays: Dict[str, float]):
        if delays is None:
            return
        env = self.get_env(instance_id)
        env.metadata["aicrowd_client_delays"] = delays
